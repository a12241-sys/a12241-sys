import pygame, random, json, os, math, array
pygame.init()
pygame.mixer.init()

# ---------------- CONFIGURAÇÃO ----------------
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Star Wars Battle")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 30)
font_large = pygame.font.SysFont(None, 50)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------- ESTADOS ----------------
MENU, PLAY, GAMEOVER, RANK = 0, 1, 2, 3
state = MENU

# ---------------- CARREGAR IMAGENS ----------------
def carregar_sprite(nome, largura, altura):
    """Carrega imagem ou cria fallback procedural"""
    caminho = os.path.join(BASE_DIR, nome)
    try:
        if os.path.exists(caminho):
            img = pygame.image.load(caminho).convert_alpha()
            return pygame.transform.scale(img, (largura, altura))
    except Exception as e:
        print(f"⚠️ Imagem '{nome}' não carregada: {e}")
    
    # Fallback - cria sprite procedural
    surf = pygame.Surface((largura, altura), pygame.SRCALPHA)
    if "jedi" in nome.lower():
        pygame.draw.circle(surf, (0, 150, 255), (largura//2, altura//2), altura//2)
        pygame.draw.circle(surf, (100, 200, 255), (largura//2, altura//2), altura//3)
    elif "sith" in nome.lower():
        pygame.draw.circle(surf, (255, 0, 0), (largura//2, altura//2), altura//2)
        pygame.draw.circle(surf, (150, 0, 0), (largura//2, altura//2), altura//3)
    elif "boss" in nome.lower():
        pygame.draw.rect(surf, (150, 0, 150), (0, 0, largura, altura))
        pygame.draw.rect(surf, (200, 50, 200), (10, 10, largura-20, altura-20))
    else:
        pygame.draw.rect(surf, (0, 255, 0), (0, 0, largura, altura))
    return surf

# ---------------- SONS (Fallback se não existir) ----------------
def load_sound(name):
    """Carrega som ou gera fallback procedural"""
    path = os.path.join(BASE_DIR, name)
    if os.path.exists(path):
        try:
            return pygame.mixer.Sound(path)
        except: pass
    # Gera som procedural
    freq = 800 if "laser" in name else 150
    dur = 0.15 if "laser" in name else 0.3
    samples = [int(0.3 * 32767 * math.sin(2 * math.pi * freq * i / 44100)) 
               for i in range(int(44100 * dur)) for _ in range(2)]
    return pygame.mixer.Sound(buffer=array.array('h', samples))

# ✅ NOMES CORRETOS DOS SONS
som_laser = load_sound("laser.wav")       # laser.wav (não laser.mp3)
som_explosao = load_sound("explosion.wav")
som_boss = load_sound("boss.wav")
som_laser.set_volume(0.5)
som_explosao.set_volume(0.5)
som_boss.set_volume(0.5)

# ---------------- EXCEÇÕES ----------------
class ForcaInsuficienteError(Exception): pass
class SabreInvalidoError(Exception): pass

# ---------------- CLASSES ----------------
class SabreDeLuz:
    def __init__(self, cor):
        self.cor = cor
        self.dano = lambda: 25  # Lambda obrigatório

class Personagem(pygame.sprite.Sprite):
    def __init__(self, nome, cor, x, y, vida, forca, sprite):
        super().__init__()
        self.nome, self.vida, self.vida_max, self.forca = nome, vida, vida, forca
        self.sabre = SabreDeLuz(cor)  # Composição
        self.image = carregar_sprite(sprite, 50, 50)
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 5

    def atacar(self):
        if self.forca <= 0: 
            raise ForcaInsuficienteError()
        self.forca -= 5
        return self.sabre.dano()

    def sofrer_dano(self, dano):
        self.vida -= dano

class Jedi(Personagem):
    def __init__(self):
        super().__init__("Jedi", "azul", WIDTH//2, HEIGHT-60, 100, 80, "jedi.png")
        self.vidas = 5  # DESAFIO 4
    
    def draw(self, surface):
        surface.blit(self.image, self.rect)

class Sith(Personagem):
    def __init__(self):
        super().__init__("Sith", "vermelho", random.randint(40, WIDTH-40), 
                        random.randint(-300, -40), 60, 50, "sith.png")
        self.speed = random.randint(2, 4)
    
    def update(self):
        self.rect.y += self.speed
        if self.rect.top > HEIGHT:
            self.rect.bottom = 0
            self.rect.x = random.randint(40, WIDTH-40)
    
    # DESAFIO 1 - Barra de vida dinâmica
    def desenhar_barra_vida(self, surf):
        pct = max(0, self.vida / self.vida_max)
        cor = (0, 255, 0) if pct > 0.6 else (255, 255, 0) if pct > 0.3 else (255, 0, 0)
        x, y = self.rect.centerx - 20, self.rect.top - 10
        pygame.draw.rect(surf, (100, 0, 0), (x, y, 40, 6))
        pygame.draw.rect(surf, cor, (x, y, 40 * pct, 6))

class Boss(Personagem):  # DESAFIO 8 - Criatividade
    def __init__(self, level=1):
        super().__init__("Boss", "roxo", WIDTH//2, -50, 100 + level*50, 100, "boss.png")
        self.level = level
        self.speed = 1 + level * 0.2
        self.image = carregar_sprite("boss.png", 100 + level*10, 60 + level*5)
    
    def update(self):
        self.rect.y += self.speed
        if self.rect.top > 50: self.speed = 0
        self.rect.x += random.randint(-2, 2)
        self.rect.clamp_ip(pygame.Rect(0, 0, WIDTH, HEIGHT))
    
    def desenhar_barra_vida(self, surf):
        pct = max(0, self.vida / self.vida_max)
        x, y = self.rect.centerx - 75, self.rect.bottom + 10
        pygame.draw.rect(surf, (100, 0, 0), (x, y, 150, 10))
        pygame.draw.rect(surf, (255, 0, 0), (x, y, 150 * pct, 10))
        pygame.draw.rect(surf, (255, 255, 255), (x, y, 150, 10), 2)
        texto = font.render(f"BOSS NÍVEL {self.level}", True, (255, 255, 255))
        surf.blit(texto, (x, y - 25))

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, enemy=False):
        super().__init__()
        self.image = pygame.Surface((6, 15), pygame.SRCALPHA)
        pygame.draw.ellipse(self.image, (255, 0, 0) if enemy else (0, 150, 255), (0, 0, 6, 15))
        pygame.draw.ellipse(self.image, (255, 200, 200) if enemy else (100, 200, 255), (1, 2, 4, 11))
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 5 if enemy else -7
    
    def update(self):
        self.rect.y += self.speed
        if self.rect.bottom < 0 or self.rect.top > HEIGHT: self.kill()

class Explosao(pygame.sprite.Sprite):
    def __init__(self, x, y, grande=False):
        super().__init__()
        self.frames = []
        for r in range(10, 80 if grande else 50, 8):
            img = pygame.Surface((r, r), pygame.SRCALPHA)
            pygame.draw.circle(img, (255, 165, 0), (r//2, r//2), r//2)
            pygame.draw.circle(img, (255, 255, 200), (r//2, r//2), r//3)
            self.frames.append(img)
        self.index = 0
        self.image = self.frames[0]
        self.rect = self.image.get_rect(center=(x, y))
    
    def update(self):
        self.index += 0.4
        if self.index >= len(self.frames): self.kill()
        else: self.image = self.frames[int(self.index)]

# ---------------- FUNDO ESPACIAL ----------------
class StarField:
    def __init__(self):
        self.stars = []
        for _ in range(150):
            self.stars.append([
                random.randint(0, WIDTH),
                random.randint(0, HEIGHT),
                random.randint(1, 3),
                random.randint(1, 4),
                random.randint(150, 255)
            ])
    
    def update(self):
        for star in self.stars:
            star[1] += star[3]
            if star[1] > HEIGHT:
                star[1] = 0
                star[0] = random.randint(0, WIDTH)
    
    def draw(self, surface):
        surface.fill((0, 0, 30))
        for star in self.stars:
            pygame.draw.circle(surface, (star[4], star[4], star[4]), 
                             (int(star[0]), int(star[1])), star[2])

# ---------------- RANKING (DESAFIO 6) ----------------
def carregar_ranking():
    try:
        with open(os.path.join(BASE_DIR, "ranking.json"), "r") as f:
            return json.load(f)
    except: return []

def salvar_ranking(nome, pontos):
    ranking = carregar_ranking()
    ranking.append({"nome": nome[:10].upper(), "pontos": pontos})
    ranking.sort(key=lambda x: -x["pontos"])
    with open(os.path.join(BASE_DIR, "ranking.json"), "w") as f:
        json.dump(ranking[:10], f, indent=2)

# ---------------- FUNÇÕES AUXILIARES ----------------
def draw_text(txt, y, color=(255,255,255), size=30, center=True):
    f = pygame.font.SysFont(None, size)
    s = f.render(txt, True, color)
    r = s.get_rect(center=(WIDTH//2, y) if center else (10, y))
    screen.blit(s, r)

def draw_button(text, y, hover=False):
    rect = pygame.Rect(WIDTH//2 - 175, y, 350, 60)
    cor = (80, 80, 150) if hover else (40, 40, 80)
    pygame.draw.rect(screen, cor, rect, border_radius=15)
    pygame.draw.rect(screen, (255, 255, 100) if hover else (150, 150, 200), rect, 4, border_radius=15)
    draw_text(text, y + 30, (255, 255, 100) if hover else (200, 200, 255))
    return rect

# ---------------- INICIALIZAÇÃO ----------------
star_field = StarField()
all_sprites = pygame.sprite.Group()
bullets = pygame.sprite.Group()
enemies = pygame.sprite.Group()
jedi = Jedi()
all_sprites.add(jedi)

for _ in range(5):
    s = Sith()
    enemies.add(s)
    all_sprites.add(s)

boss = None
boss_active = False
boss_level = 1
score = 0
last_shot = 0
player_name = ""
input_text = ""
input_active = False
running = True

# ---------------- LOOP PRINCIPAL ----------------
while running:
    clock.tick(60)
    star_field.update()
    star_field.draw(screen)
    keys = pygame.key.get_pressed()
    mouse_pos = pygame.mouse.get_pos()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        if event.type == pygame.KEYDOWN:
            # MENU
            if state == MENU:
                if event.key == pygame.K_1: state = PLAY; break
                if event.key == pygame.K_2: state = RANK; break
                if event.key == pygame.K_ESCAPE: running = False
            
            # JOGO
            elif state == PLAY:
                if event.key == pygame.K_SPACE and not boss_active:
                    # DESAFIO 2 - Limite de 3 tiros
                    if len(bullets) < 3 and pygame.time.get_ticks() - last_shot > 200:
                        bullets.add(Bullet(jedi.rect.centerx, jedi.rect.top))
                        som_laser.play()
                        last_shot = pygame.time.get_ticks()
                elif event.key == pygame.K_SPACE and boss_active:
                    if pygame.time.get_ticks() - last_shot > 200:
                        bullets.add(Bullet(jedi.rect.centerx, jedi.rect.top))
                        som_laser.play()
                        last_shot = pygame.time.get_ticks()
                if event.key == pygame.K_r: state = RANK
                if event.key == pygame.K_ESCAPE: state = MENU
            
            # GAME OVER - Input de nome
            elif state == GAMEOVER and input_active:
                if event.key == pygame.K_RETURN and input_text.strip():
                    salvar_ranking(input_text, score)
                    input_active = False
                elif event.key == pygame.K_BACKSPACE:
                    input_text = input_text[:-1]
                elif event.unicode.isalnum() and len(input_text) < 10:
                    input_text += event.unicode.upper()
            
            # GAME OVER / RANKING
            elif state in [GAMEOVER, RANK]:
                if event.key == pygame.K_RETURN or event.key == pygame.K_ESCAPE:
                    state = MENU
                    input_active = False
                    input_text = ""
        
        # MENU - Click nos botões
        if state == MENU and event.type == pygame.MOUSEBUTTONDOWN:
            if draw_button("🎮 JOGAR", 250).collidepoint(mouse_pos):
                state = PLAY; score = 0; jedi.vidas = 5; jedi.rect.center = (WIDTH//2, HEIGHT-60)
                for e in enemies: e.kill()
                for _ in range(5): 
                    s = Sith(); enemies.add(s); all_sprites.add(s)
                boss = None; boss_active = False; boss_level = 1
            if draw_button("🏆 RANKING", 330).collidepoint(mouse_pos): state = RANK
            if draw_button("🚪 SAIR", 410).collidepoint(mouse_pos): running = False
    
    # ---------------- ESTADO: MENU ----------------
    if state == MENU:
        draw_text("STAR WARS BATTLE", 150, (255, 215, 0), 50)
        draw_text("1 - JOGAR | 2 - RANKING | ESC - SAIR", 500, (150, 200, 255))
        
        # Botões com hover
        draw_button("🎮 JOGAR", 250, draw_button("🎮 JOGAR", 250).collidepoint(mouse_pos))
        draw_button("🏆 RANKING", 330, draw_button("🏆 RANKING", 330).collidepoint(mouse_pos))
        draw_button("🚪 SAIR", 410, draw_button("🚪 SAIR", 410).collidepoint(mouse_pos))
    
    # ---------------- ESTADO: JOGO ----------------
    elif state == PLAY:
        # DESAFIO 8 - Spawn Boss a cada 100 pontos
        if score > 0 and score % 100 == 0 and not boss_active and not boss:
            boss = Boss(boss_level)
            boss_active = True
            all_sprites.add(boss)
            enemies.empty()
            som_boss.play()
        
        # Movimento Jedi
        jedi.rect.x += (keys[pygame.K_RIGHT] - keys[pygame.K_LEFT]) * jedi.speed
        jedi.rect.clamp_ip(pygame.Rect(0, 0, WIDTH, HEIGHT))
        
        # Updates
        all_sprites.update()
        bullets.update()
        if boss: boss.update()
        
        # Boss dispara
        if boss_active and boss and random.random() < 0.02:
            bullets.add(Bullet(boss.rect.centerx, boss.rect.bottom, enemy=True))
        
        # Colisão Tiro ↔ Inimigo
        for b in bullets:
            if b.speed < 0:  # Tiro Jedi
                target = [boss] if boss_active else enemies
                hits = pygame.sprite.spritecollide(b, target, False)
                for e in hits:
                    e.sofrer_dano(25)
                    b.kill()
                    if e.vida <= 0:
                        # DESAFIO 5 - Pontuação
                        score += 50 if boss_active else 10
                        som_explosao.play()
                        all_sprites.add(Explosao(e.rect.centerx, e.rect.centery, boss_active))
                        e.kill()
                        if boss_active:
                            boss = None
                            boss_active = False
                            boss_level += 1
                            for _ in range(5):
                                s = Sith(); enemies.add(s); all_sprites.add(s)
                        else:
                            s = Sith(); enemies.add(s); all_sprites.add(s)
            else:  # Tiro Inimigo
                if pygame.sprite.collide_rect(b, jedi):
                    b.kill()
                    jedi.vidas -= 1
        
        # DESAFIO 3 - Colisão Jedi ↔ Sith
        if not boss_active:
            hits = pygame.sprite.spritecollide(jedi, enemies, True)
            if hits:
                jedi.vidas -= 1
                jedi.rect.center = (WIDTH//2, HEIGHT-60)
                s = Sith(); enemies.add(s); all_sprites.add(s)
        
        # DESAFIO 4 - Game Over
        if jedi.vidas <= 0:
            state = GAMEOVER
            input_active = True
        
        # Draw
        all_sprites.draw(screen)
        bullets.draw(screen)
        jedi.draw(screen)
        for e in enemies: e.desenhar_barra_vida(screen)
        if boss: boss.desenhar_barra_vida(screen)
        
        # UI
        draw_text(f"Score: {score}", 20, (255, 255, 100), center=False)
        draw_text(f"Vidas: {jedi.vidas}", 20, (100, 255, 100), center=False)
        if boss_active:
            draw_text(f"🚀 BOSS NÍVEL {boss_level}!", 20, (255, 100, 100))
        else:
            draw_text(f"Tiros: {len(bullets)}/3", 50, (150, 200, 255))
        draw_text("Setas: Mover | ESPAÇO: Atirar | R: Ranking | ESC: Menu", HEIGHT-20, (150, 200, 255), 20)
    
    # ---------------- ESTADO: GAME OVER ----------------
    elif state == GAMEOVER:
        draw_text("GAME OVER", 150, (255, 100, 100), 50)
        draw_text(f"Score Final: {score}", 220, (255, 255, 100), 40)
        
        # DESAFIO 7 - Mostrar Ranking
        ranking = carregar_ranking()
        if ranking:
            draw_text("TOP 3 RANKING", 300, (255, 215, 0), 30)
            for i, r in enumerate(ranking[:3], 1):
                cor = [(255, 215, 0), (192, 192, 192), (205, 127, 50)][i-1]
                draw_text(f"{i}º {r['nome']}: {r['pontos']}", 340 + i*30, cor)
        
        if input_active:
            draw_text("Digite seu nome:", 480, (200, 200, 255))
            draw_text(f"{input_text}_", 520, (255, 255, 100), 40)
            draw_text("ENTER para salvar", 570, (150, 200, 255), 20)
        else:
            draw_text("ENTER/ESC: Menu", 550, (150, 200, 255))
    
    # ---------------- ESTADO: RANKING ----------------
    elif state == RANK:
        # DESAFIO 6 & 7
        draw_text("🏆 RANKING TOP 10", 50, (255, 215, 0), 40)
        ranking = carregar_ranking()
        for i, r in enumerate(ranking[:10], 1):
            cor = (255, 215, 0) if i==1 else (192, 192, 192) if i==2 else (205, 127, 50) if i==3 else (255, 255, 255)
            draw_text(f"{i}º {r['nome']}: {r['pontos']}", 100 + i*35, cor)
        draw_text("ESC/ENTER: Voltar", HEIGHT-40, (150, 200, 255))
    
    pygame.display.flip()

pygame.quit()