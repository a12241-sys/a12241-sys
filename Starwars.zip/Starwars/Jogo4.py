import pygame
import random
import os
import json

# =============================================================================
# INICIALIZAÇÃO DO PYGAME
# =============================================================================
pygame.init()           # Inicializa módulos principais do Pygame
pygame.mixer.init()     # Inicializa módulo de áudio para sons e música

# =============================================================================
# CONFIGURAÇÕES GERAIS DO JOGO
# =============================================================================
WIDTH, HEIGHT = 800, 600                           # Dimensões da janela do jogo
screen = pygame.display.set_mode((WIDTH, HEIGHT))  # Cria a superfície de desenho
pygame.display.set_caption("Star Wars Battle")     # Define título da janela
clock = pygame.time.Clock()                        # Controla o FPS do jogo

# Fontes para textos na interface
font = pygame.font.SysFont(None, 30)      # Fonte padrão (pequena)
font_large = pygame.font.SysFont(None, 50) # Fonte média para menus
font_title = pygame.font.SysFont(None, 70) # Fonte grande para títulos

# Configurações de mecânicas de jogo
MAX_BALAS_TELA = 3      # Limite de projéteis ativos para balanceamento
SHOT_COOLDOWN = 200     # Tempo mínimo entre tiros em milissegundos

# Diretório base para carregar assets (imagens, sons)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# =============================================================================
# CARREGAMENTO DE SONS
# =============================================================================
def carregar_som(nome_ficheiro):
    """
    Carrega um arquivo de som com tratamento de erros.
    
    Args:
        nome_ficheiro (str): Nome do arquivo de áudio na pasta do jogo
    
    Returns:
        pygame.mixer.Sound ou None: Objeto de som carregado ou None se falhar
    """
    caminho = os.path.join(BASE_DIR, nome_ficheiro)
    
    # Verifica se o arquivo existe antes de tentar carregar
    if not os.path.exists(caminho):
        print(f"⚠️ Som não encontrado: {nome_ficheiro}")
        return None
    
    try:
        som = pygame.mixer.Sound(caminho)
        return som
    except Exception as e:
        print(f"⚠️ Erro ao carregar som: {e}")
        return None

# Carrega sons do jogo (laser e explosão)
som_laser = carregar_som("laser.wav")
som_explosao = carregar_som("explosion.wav")

# Ajusta volumes se os sons foram carregados com sucesso
if som_laser:
    som_laser.set_volume(0.5)   # Volume 50% para o laser
if som_explosao:
    som_explosao.set_volume(0.6) # Volume 60% para explosões

# =============================================================================
# FUNÇÕES AUXILIARES DE ASSETS E INTERFACE
# =============================================================================
def carregar_sprite(nome, largura, altura):
    """
    Carrega e redimensiona uma imagem sprite com fallback para cor sólida.
    
    Args:
        nome (str): Nome do arquivo de imagem
        largura (int): Largura desejada para o sprite
        altura (int): Altura desejada para o sprite
    
    Returns:
        pygame.Surface: Imagem carregada ou superfície colorida de fallback
    """
    try:
        img = pygame.image.load(os.path.join(BASE_DIR, nome)).convert_alpha()
        return pygame.transform.scale(img, (largura, altura))
    except:
        # Fallback: cria superfície colorida se imagem não existir
        surf = pygame.Surface((largura, altura))
        if "jedi" in nome:
            surf.fill((0, 0, 255))      # Azul para Jedi
        elif "sith" in nome:
            surf.fill((255, 0, 0))      # Vermelho para Sith
        else:
            surf.fill((255, 255, 255))  # Branco para outros
        return surf

def desenhar_menu(screen, opcoes, opcao_selecionada, mouse_pos):
    """
    Desenha a tela do menu principal com opções interativas.
    
    Args:
        screen: Superfície do Pygame para desenho
        opcoes (list): Lista de strings com textos das opções
        opcao_selecionada (int): Índice da opção atualmente selecionada
        mouse_pos (tuple): Posição atual do rato (x, y) para hover
    """
    screen.fill((0, 0, 0))  # Fundo preto
    
    # Título principal do jogo com cor dourada Star Wars
    titulo = font_title.render("STAR WARS BATTLE", True, (255, 215, 0))
    screen.blit(titulo, (WIDTH//2 - titulo.get_width()//2, 80))
    
    # Desenha cada opção do menu com efeitos de hover e seleção
    for i, opcao in enumerate(opcoes):
        # Detecta se o rato está sobre esta opção (área de clique)
        esta_sobre = (100 <= mouse_pos[0] <= 700 and 
                     200 + i*60 <= mouse_pos[1] <= 260 + i*60)
        
        # Define cores baseadas no estado da opção
        if i == opcao_selecionada:
            cor = (255, 255, 0)  # Amarelo para opção selecionada via teclado
            texto = font_large.render(f"> {opcao} <", True, cor)
        elif esta_sobre:
            cor = (200, 255, 200)  # Verde claro para hover do rato
            texto = font_large.render(opcao, True, cor)
        else:
            cor = (255, 255, 255)  # Branco para opção normal
            texto = font_large.render(opcao, True, cor)
        
        # Centraliza horizontalmente e posiciona verticalmente com espaçamento
        screen.blit(texto, (WIDTH//2 - texto.get_width()//2, 250 + i * 60))
    
    # Instruções de controlo na parte inferior
    instrucoes = font.render("Use rato ou SETAS + ENTER", True, (150, 150, 150))
    screen.blit(instrucoes, (WIDTH//2 - instrucoes.get_width()//2, HEIGHT - 50))

def desenhar_ranking(screen):
    """
    Desenha a tela de ranking com top 10 jogadores salvos em JSON.
    
    Args:
        screen: Superfície do Pygame para desenho
    """
    screen.fill((0, 0, 0))  # Fundo preto
    
    # Título da tela de ranking
    titulo = font_title.render("RANKING TOP 10", True, (255, 215, 0))
    screen.blit(titulo, (WIDTH//2 - titulo.get_width()//2, 50))
    
    # Carrega dados do ranking com tratamento de erro para arquivo inexistente
    try:
        with open('ranking.json', 'r') as f:
            ranking = json.load(f)
    except:
        ranking = []  # Lista vazia se arquivo não existir ou estiver corrompido
    
    # Cabeçalhos da tabela e configurações de layout
    cabecalhos = ["POS", "NOME", "PONTOS"]
    larguras = [80, 400, 150]  # Largura de cada coluna em pixels
    x_inicial = 135  # Posição X inicial da tabela
    
    # Desenha cabeçalhos da tabela
    y = 130
    for i, cabecalho in enumerate(cabecalhos):
        x = x_inicial + sum(larguras[:i])  # Calcula posição X da coluna
        texto = font_large.render(cabecalho, True, (255, 215, 0))
        # Centraliza texto dentro da largura da coluna
        screen.blit(texto, (x + (larguras[i] - texto.get_width())//2, y))
    
    # Linha separadora entre cabeçalho e conteúdo
    pygame.draw.line(screen, (255, 215, 0), (x_inicial - 20, 165), 
                     (x_inicial - 20 + sum(larguras) + 40, 165), 2)
    
    # Desenha entradas do ranking ou mensagem de lista vazia
    y = 190
    if not ranking:
        texto = font.render("Nenhum jogo registado!", True, (200, 200, 200))
        screen.blit(texto, (WIDTH//2 - texto.get_width()//2, 300))
    else:
        for i, entrada in enumerate(ranking):
            # Posição com ícone #
            pos = font.render(f"#{i+1}", True, (255, 215, 0))
            screen.blit(pos, (x_inicial + 20, y + 10))
            
            # Nome do jogador
            nome = entrada.get('nome', 'Desconhecido')
            nome_txt = font.render(nome, True, (255, 255, 255))
            screen.blit(nome_txt, (x_inicial + 100, y + 10))
            
            # Pontuação em verde
            pontos = entrada.get('pontuacao', 0)
            pontos_txt = font.render(f"{pontos}", True, (0, 255, 0))
            screen.blit(pontos_txt, (x_inicial + 500, y + 10))
            
            y += 40  # Espaçamento vertical entre linhas
    
    # Instrução para voltar ao menu
    voltar = font.render("Clique para voltar", True, (150, 150, 150))
    screen.blit(voltar, (WIDTH//2 - voltar.get_width()//2, HEIGHT - 50))

def guardar_ranking(nome, pontuacao):
    """
    Salva ou atualiza o ranking em arquivo JSON com top 10.
    
    Args:
        nome (str): Nome do jogador
        pontuacao (int): Pontuação final alcançada
    """
    # Carrega ranking existente ou cria lista vazia
    try:
        with open('ranking.json', 'r') as f:
            ranking = json.load(f)
    except:
        ranking = []
    
    # Adiciona nova entrada e ordena por pontuação decrescente
    ranking.append({"nome": nome, "pontuacao": pontuacao})
    ranking.sort(key=lambda x: x.get('pontuacao', 0), reverse=True)
    
    # Mantém apenas top 10 jogadores
    ranking = ranking[:10]
    
    # Salva arquivo JSON formatado com indentação para legibilidade
    with open('ranking.json', 'w') as f:
        json.dump(ranking, f, indent=4)

# =============================================================================
# CLASSES DO JOGO (SPRITES) 
# =============================================================================
class Personagem(pygame.sprite.Sprite): 
    """
    Classe base para todos os personagens do jogo.
    Herda de pygame.sprite.Sprite para integração com grupos de sprites.
    """
    def __init__(self, nome, cor, x, y, vida, sprite): 
        super().__init__() 
        self.nome = nome           # Nome identificador do personagem
        self.vida = vida           # Vida atual
        self.vida_max = vida       # Vida máxima para cálculo de percentagem
        self.image = carregar_sprite(sprite, 50, 50)
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 5             # Velocidade base de movimento

    def sofrer_dano(self, dano): 
        """Reduz a vida do personagem pelo valor do dano recebido."""
        self.vida -= dano

    def desenhar_barra_vida(self, superficie): 
        """Desenha barra de vida acima do personagem com cor dinâmica."""
        largura, altura = 40, 6
        percentagem = max(0, self.vida / self.vida_max)
        
        # Define cor da barra: verde > amarelo > vermelho
        cor = (0, 255, 0) if percentagem > 0.6 else (255, 255, 0) if percentagem > 0.3 else (255, 0, 0)
        
        x = self.rect.centerx - largura // 2
        y = self.rect.top - 10
        
        pygame.draw.rect(superficie, (50, 0, 0), (x, y, largura, altura))
        pygame.draw.rect(superficie, cor, (x, y, largura * percentagem, altura))


class Jedi(Personagem): 
    """Classe do jogador (Jedi) com controlo do utilizador."""
    def __init__(self): 
        super().__init__("Jedi", "azul", WIDTH // 2, HEIGHT - 60, 100, "jedi.png") 
        self.vidas = 5  # Número de vidas extras do jogador


class Sith(Personagem): 
    """Classe dos inimigos (Sith) com movimento automático e IA básica."""
    def __init__(self, dificuldade=1): 
        x = random.randint(40, WIDTH - 40)
        y = random.randint(-300, -40)
        super().__init__("Sith", "vermelho", x, y, 60, "sith.png")
        self.speed = random.randint(2, 4) * dificuldade

    def update(self): 
        """Move o Sith para baixo e respawn no topo se sair do ecrã."""
        self.rect.y += self.speed
        if self.rect.top > HEIGHT: 
            self.rect.bottom = 0
            self.rect.x = random.randint(40, WIDTH - 40)


class Projétil(pygame.sprite.Sprite):  # ✅ Traduzido de Bullet
    """Classe para projéteis disparados pelo Jedi."""
    def __init__(self, x, y): 
        super().__init__() 
        self.image = pygame.Surface((6, 16))
        self.image.fill((255, 255, 255))  # Cor branca para o laser
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = -7  # Velocidade negativa = movimento para cima

    def update(self): 
        """Move o projétil e remove se sair do ecrã."""
        self.rect.y += self.speed 
        if self.rect.bottom < 0:
            self.kill()


class Explosão(pygame.sprite.Sprite):  # ✅ Correção ortográfica
    """Classe para efeito visual de explosão animada."""
    def __init__(self, x, y): 
        super().__init__() 
        # Gera frames de animação: círculos crescentes laranja
        self.frames = []
        for r in range(10, 50, 8):
            img = pygame.Surface((r, r), pygame.SRCALPHA)
            pygame.draw.circle(img, (255, 165, 0), (r // 2, r // 2), r // 2)
            self.frames.append(img)
        
        self.index = 0
        self.image = self.frames[0]
        self.rect = self.image.get_rect(center=(x, y))

    def update(self): 
        """Avança animação e remove sprite quando terminar."""
        self.index += 0.4
        if self.index >= len(self.frames):
            self.kill()
        else:
            self.image = self.frames[int(self.index)]


# =============================================================================
# FUNÇÃO PRINCIPAL DO JOGO (GAMEPLAY)
# =============================================================================
def jogo_principal():
    """
    Loop principal do gameplay: controla lógica, eventos e renderização.
    
    Returns:
        tuple: (continuar: bool, pontuacao: int) 
               - continuar: se deve voltar ao menu ou encerrar
               - pontuacao: score final do jogador
    """
    # Grupos de sprites para gerenciamento automático de update/draw
    all_sprites = pygame.sprite.Group()  # Todos os sprites ativos
    bullets = pygame.sprite.Group()      # Apenas projéteis
    enemies = pygame.sprite.Group()      # Apenas inimigos
    
    # Cria jogador Jedi e adiciona aos grupos
    jedi = Jedi()
    all_sprites.add(jedi)
    
    # Cria onda inicial de 5 inimigos Sith
    for _ in range(5):
        sith = Sith()
        enemies.add(sith)
        all_sprites.add(sith)
    
    # Variáveis de estado do jogo
    pontuacao = 0              # Score acumulado
    game_over = False          # Flag para fim de jogo
    waiting_for_name = False   # Flag para tela de input de nome
    nome_jogador = ""          # String para armazenar nome digitado
    dificuldade = 1            # Multiplicador de dificuldade inicial
    last_shot = 0              # Timestamp do último tiro para cooldown
    
    running = True
    while running:
        clock.tick(60)  # Limita loop a 60 FPS para consistência entre hardware
        
        # =====================================================================
        # PROCESSAMENTO DE EVENTOS (INPUT)
        # =====================================================================
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False, 0  # Encerra jogo completamente
            
            if event.type == pygame.KEYDOWN:
                # === TELA DE INPUT DE NOME (pós game over) ===
                if waiting_for_name:
                    if event.key == pygame.K_RETURN:
                        # Salva ranking se nome não estiver vazio
                        if nome_jogador.strip():
                            guardar_ranking(nome_jogador, pontuacao)
                        return True, pontuacao  # Volta ao menu
                    elif event.key == pygame.K_BACKSPACE:
                        nome_jogador = nome_jogador[:-1]  # Remove último caractere
                    elif len(nome_jogador) < 12 and event.unicode.isprintable():
                        nome_jogador += event.unicode  # Adiciona caractere digitado
                
                # === CONTROLES GERAIS ===
                elif event.key == pygame.K_ESCAPE:
                    return True, pontuacao  # Sai para menu com ESC
                elif event.key == pygame.K_SPACE and not game_over:
                    # === DISPARO DE LASER ===
                    now = pygame.time.get_ticks()
                    # Verifica limites: munição na tela + cooldown
                    if len(bullets) < MAX_BALAS_TELA and now - last_shot >= SHOT_COOLDOWN:
                        # ✅ Bullet → Projétil
                        b = Projétil(jedi.rect.centerx, jedi.rect.top)
                        bullets.add(b)
                        all_sprites.add(b)
                        if som_laser:
                            som_laser.play()
                        last_shot = now  # Atualiza timestamp para cooldown
        
        # =====================================================================
        # LÓGICA DO JOGO (apenas se não estiver em game over ou input)
        # =====================================================================
        if not game_over and not waiting_for_name:
            # === MOVIMENTO DO JOGADOR ===
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and jedi.rect.left > 0:
                jedi.rect.x -= jedi.speed  # Move esquerda com limite de ecrã
            if keys[pygame.K_RIGHT] and jedi.rect.right < WIDTH:
                jedi.rect.x += jedi.speed  # Move direita com limite de ecrã
            
            # === ATUALIZA TODOS OS SPRITES ===
            all_sprites.update()
            
            # === COLISÃO: TIROS vs INIMIGOS ===
            # groupcollide: (grupo1, grupo2, kill1, kill2)
            hits = pygame.sprite.groupcollide(enemies, bullets, False, True)
            for enemy in hits:
                enemy.sofrer_dano(25)  # Cada tiro causa 25 de dano
                if enemy.vida <= 0:
                    pontuacao += 10  # Recompensa por destruir inimigo
                    if som_explosao:
                        som_explosao.play()
                    # Cria efeito visual de explosão na posição do inimigo
                    # ✅ Explosao → Explosão
                    all_sprites.add(Explosão(enemy.rect.centerx, enemy.rect.centery))
                    enemy.kill()  # Remove inimigo destruído
                    
                    # Spawn de novo inimigo para manter fluxo do jogo
                    novo = Sith(dificuldade)
                    enemies.add(novo)
                    all_sprites.add(novo)
                    
                    # === SISTEMA DE DIFICULDADE PROGRESSIVA ===
                    # Aumenta dificuldade a cada 50 pontos
                    if pontuacao % 50 == 0 and pontuacao > 0:
                        dificuldade += 0.5
            
            # === COLISÃO: JEDI vs INIMIGOS (dano ao jogador) ===
            # spritecollide: (sprite, grupo, dokill) - dokill=True remove inimigo na colisão
            hits_jedi = pygame.sprite.spritecollide(jedi, enemies, True)
            if hits_jedi:
                jedi.vidas -= len(hits_jedi)  # Perde 1 vida por inimigo colidido
                # Reposiciona Jedi no centro inferior após colisão
                jedi.rect.center = (WIDTH // 2, HEIGHT - 60)
                
                # Respawn dos inimigos que colidiram
                for _ in hits_jedi:
                    novo = Sith(dificuldade)
                    enemies.add(novo)
                    all_sprites.add(novo)
                
                # === CONDIÇÃO DE GAME OVER ===
                if jedi.vidas <= 0:
                    game_over = True
                    waiting_for_name = True  # Ativa tela de input de nome
        
        # =====================================================================
        # RENDERIZAÇÃO (DESENHO NO ECRÃ)
        # =====================================================================
        screen.fill((0, 0, 0))  # Limpa ecrã com fundo preto a cada frame
        
        if not game_over and not waiting_for_name:
            # Desenha todos os sprites ativos
            all_sprites.draw(screen)
            # Desenha barras de vida individuais para cada inimigo
            for enemy in enemies:
                enemy.desenhar_barra_vida(screen)
            
            # === INTERFACE DO JOGO (HUD) ===
            # Score no canto superior esquerdo
            screen.blit(font.render(f"Score: {pontuacao}", True, (255, 255, 255)), (10, 10))
            # Vidas restantes
            screen.blit(font.render(f"Vidas: {jedi.vidas}", True, (255, 255, 255)), (10, 40))
            # Nível de dificuldade atual (canto superior direito, cor dourada)
            screen.blit(font.render(f"Dificuldade: {dificuldade:.1f}", True, (255, 215, 0)), (WIDTH - 200, 10))
        
        # === TELA DE GAME OVER + INPUT DE NOME ===
        if game_over and waiting_for_name:
            screen.blit(font_large.render("GAME OVER", True, (255, 0, 0)), 
                       (WIDTH//2 - 100, HEIGHT//2 - 80))
            screen.blit(font.render(f"Pontos: {pontuacao}", True, (255, 255, 0)), 
                       (WIDTH//2 - 80, HEIGHT//2 - 20))
            # Campo de input com cursor piscante simulado por "_"
            screen.blit(font.render("Nome: " + nome_jogador + "_", True, (255, 255, 255)), 
                       (WIDTH//2 - 100, HEIGHT//2 + 30))
            screen.blit(font.render("ENTER para guardar", True, (150, 150, 150)), 
                       (WIDTH//2 - 80, HEIGHT//2 + 70))
        
        # Atualiza display com tudo desenhado neste frame
        pygame.display.flip()
    
    return False, 0  # Fallback de retorno (não deve ser alcançado normalmente)


# =============================================================================
# LOOP PRINCIPAL DA APLICAÇÃO (GERENCIAMENTO DE ESTADOS)
# =============================================================================
def main():
    """
    Função principal que gerencia estados da aplicação: MENU, JOGO, RANKING.
    Implementa máquina de estados simples para navegação entre telas.
    """
    estado = "MENU"              # Estado inicial da aplicação
    opcao_menu = 0               # Índice da opção selecionada no menu
    opcoes = ["INICIAR JOGO", "VER RANKING", "SAIR"]  # Opções disponíveis
    
    running = True
    while running:
        clock.tick(60)  # Mantém 60 FPS consistentes
        mouse_pos = pygame.mouse.get_pos()  # Posição atual do rato para hover
        
        # =====================================================================
        # PROCESSAMENTO DE EVENTOS GLOBAIS
        # =====================================================================
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False  # Encerra loop principal
            
            # === CLIQUES DO RATO ===
            if event.type == pygame.MOUSEBUTTONDOWN:
                if estado == "MENU":
                    # Detecta clique nas áreas das opções do menu
                    if 100 <= mouse_pos[0] <= 700 and 200 <= mouse_pos[1] <= 260:
                        estado = "JOGO"  # Inicia partida
                    elif 100 <= mouse_pos[0] <= 700 and 260 <= mouse_pos[1] <= 320:
                        estado = "RANKING"  # Mostra ranking
                    elif 100 <= mouse_pos[0] <= 700 and 320 <= mouse_pos[1] <= 380:
                        running = False  # Fecha aplicação
                elif estado == "RANKING":
                    estado = "MENU"  # Clique anywhere volta ao menu
            
            # === MOVIMENTO DO RATO (efeito hover no menu) ===
            if event.type == pygame.MOUSEMOTION and estado == "MENU":
                for i in range(len(opcoes)):
                    y_pos = 200 + i * 60
                    # Verifica se rato está sobre opção atual
                    if 100 <= mouse_pos[0] <= 700 and y_pos <= mouse_pos[1] <= y_pos + 60:
                        opcao_menu = i  # Atualiza seleção visual
                        break
            
            # === TECLAS NO MENU ===
            if event.type == pygame.KEYDOWN and estado == "MENU":
                if event.key == pygame.K_UP:
                    opcao_menu = (opcao_menu - 1) % len(opcoes)  # Navega cima com wrap
                elif event.key == pygame.K_DOWN:
                    opcao_menu = (opcao_menu + 1) % len(opcoes)  # Navega baixo com wrap
                elif event.key == pygame.K_RETURN:
                    # Executa ação da opção selecionada
                    if opcao_menu == 0:
                        estado = "JOGO"
                    elif opcao_menu == 1:
                        estado = "RANKING"
                    elif opcao_menu == 2:
                        running = False
        
        # =====================================================================
        # RENDERIZAÇÃO POR ESTADO
        # =====================================================================
        if estado == "MENU":
            desenhar_menu(screen, opcoes, opcao_menu, mouse_pos)
            pygame.display.flip()
        
        elif estado == "JOGO":
            # Executa loop do jogo e recebe resultado
            continuar, score = jogo_principal()
            if not continuar:
                running = False  # Encerra app se jogador saiu via QUIT
            else:
                estado = "MENU"  # Volta ao menu após partida
        
        elif estado == "RANKING":
            # Loop dedicado para tela de ranking (aguarda input para voltar)
            desenhar_ranking(screen)
            pygame.display.flip()
            aguardando = True
            while aguardando:
                clock.tick(60)
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                        aguardando = False
                    elif event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN:
                        estado = "MENU"  # Qualquer input volta ao menu
                        aguardando = False
                if not aguardando:
                    break
                # Redesenha ranking a cada frame para manter responsividade
                desenhar_ranking(screen)
                pygame.display.flip()
    
    # Limpeza final ao encerrar aplicação
    pygame.quit()


# =============================================================================
# PONTO DE ENTRADA DO PROGRAMA
# =============================================================================
# Garante que o jogo só execute quando este arquivo for executado diretamente
if __name__ == "__main__":
    main()