import pygame
import random
import os
import json
import math
import array

pygame.init()
pygame.mixer.init()

# ---------------- CONFIGURAÇÃO ----------------
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Star Wars Battle")
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 30)
font_large = pygame.font.SysFont(None, 50)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------- ESTADOS DO JOGO ----------------
STATE_MENU = "menu"
STATE_PLAYING = "playing"
STATE_GAME_OVER = "game_over"
STATE_NAME_INPUT = "name_input"
STATE_RANKING = "ranking"

# ---------------- CARREGAMENTO DE SONS ----------------
def _load_sound(nome_arquivo):
    caminho = os.path.join(BASE_DIR, nome_arquivo)
    try:
        if os.path.exists(caminho):
            return pygame.mixer.Sound(caminho)
        else:
            print(f"⚠️  Aviso: Ficheiro '{nome_arquivo}' não encontrado")
    except Exception as e:
        print(f"⚠️  Erro ao carregar '{nome_arquivo}': {e}")
    
    print(f"🔊 A gerar som de fallback para '{nome_arquivo}'")
    
    frequency = 800 if "laser" in nome_arquivo else 150
    duration = 0.15 if "laser" in nome_arquivo else 0.3
    volume = 0.3
    
    samples = []
    for i in range(int(44100 * duration)):
        if "laser" in nome_arquivo:
            freq = frequency * (1 - i / (44100 * duration) * 0.5)
        else:
            freq = frequency
        value = int(volume * 32767 * math.sin(2 * math.pi * freq * i / 44100))
        samples.append(value)
        samples.append(value)
    
    buffer = array.array('h', samples)
    sound = pygame.mixer.Sound(buffer=buffer)
    sound.set_volume(0.5)
    return sound

som_laser = _load_sound("laser.wav")
som_explosao = _load_sound("explosion.wav")
som_boss = _load_sound("boss.wav")
som_boss_shoot = _load_sound("boss_shoot.wav")

pygame.mixer.set_num_channels(16)
som_laser.set_volume(0.5)
som_explosao.set_volume(0.5)
som_boss.set_volume(0.5)
som_boss_shoot.set_volume(0.5)

# ---------------- FUNÇÕES AUXILIARES ----------------
def carregar_sprite(nome, largura, altura):
    try:
        img = pygame.image.load(os.path.join(BASE_DIR, nome)).convert_alpha()
        return pygame.transform.scale(img, (largura, altura))
    except Exception:
        surf = pygame.Surface((largura, altura), pygame.SRCALPHA)
        pygame.draw.rect(surf, (0, 255, 0), (0, 0, largura, altura))
        return surf

def draw_text_centered(text, font, color, y_offset=0, surface=None):
    if surface is None:
        surface = screen
    texto = font.render(text, True, color)
    rect = texto.get_rect(center=(surface.get_width() // 2, surface.get_height() // 2 + y_offset))
    surface.blit(texto, rect)

# ---------------- FUNDO ESPACIAL ----------------
class StarField:
    def __init__(self):
        self.stars = []
        for _ in range(150):
            x = random.randint(0, WIDTH)
            y = random.randint(0, HEIGHT)
            size = random.randint(1, 3)
            speed = random.randint(1, 4)
            brightness = random.randint(150, 255)
            self.stars.append([x, y, size, speed, brightness])
    
    def update(self):
        for star in self.stars:
            star[1] += star[3]
            if star[1] > HEIGHT:
                star[1] = 0
                star[0] = random.randint(0, WIDTH)
    
    def draw(self, surface):
        surface.fill((0, 0, 20))
        for star in self.stars:
            pygame.draw.circle(surface, (star[4], star[4], star[4]), (int(star[0]), int(star[1])), star[2])

# ---------------- CLASSES ----------------
class SabreDeLuz:
    def __init__(self, cor):
        self.cor = cor
        self.dano = lambda: 25

class Personagem(pygame.sprite.Sprite):
    def __init__(self, nome, cor, x, y, vida, forca, sprite):
        super().__init__()
        self.nome = nome
        self.vida = vida
        self.vida_max = vida
        self.forca = forca
        self.sabre = SabreDeLuz(cor)
        self.image = carregar_sprite(sprite, 50, 50)
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 5
        self.direcao = 1

    def atacar(self):
        if self.forca <= 0:
            raise Exception("Força insuficiente")
        self.forca -= 5
        return self.sabre.dano()

    def sofrer_dano(self, dano):
        self.vida -= dano
    
    def get_saber_position(self):
        offset_x = 20 * self.direcao
        offset_y = 5
        return (self.rect.centerx + offset_x, self.rect.centery + offset_y)

class Jedi(Personagem):
    def __init__(self):
        super().__init__("Jedi", "azul", WIDTH // 2, HEIGHT - 60, 100, 80, "jedi.png")
        self.vidas = 5
    
    def draw(self, surface):
        surface.blit(self.image, self.rect)
        
        saber_pos = self.get_saber_position()
        saber_length = 35
        
        pygame.draw.rect(surface, (150, 150, 150), 
                        (saber_pos[0] - 3 * self.direcao, saber_pos[1] - 10, 
                         6 * self.direcao, 15))
        
        if self.direcao == 1:
            points = [
                (saber_pos[0], saber_pos[1]),
                (saber_pos[0] + 4, saber_pos[1] - saber_length),
                (saber_pos[0] - 4, saber_pos[1] - saber_length),
                (saber_pos[0], saber_pos[1])
            ]
        else:
            points = [
                (saber_pos[0], saber_pos[1]),
                (saber_pos[0] - 4, saber_pos[1] - saber_length),
                (saber_pos[0] + 4, saber_pos[1] - saber_length),
                (saber_pos[0], saber_pos[1])
            ]
        pygame.draw.polygon(surface, (0, 100, 255), points)
        pygame.draw.polygon(surface, (100, 200, 255), 
                          [(saber_pos[0], saber_pos[1]), 
                           (saber_pos[0] + 2 * self.direcao, saber_pos[1] - saber_length + 10),
                           (saber_pos[0] - 2 * self.direcao, saber_pos[1] - saber_length + 10)])
        
        pygame.draw.circle(surface, (150, 220, 255), 
                          (int(saber_pos[0]), int(saber_pos[1] - saber_length)), 6)
        pygame.draw.circle(surface, (255, 255, 255), 
                          (int(saber_pos[0]), int(saber_pos[1] - saber_length)), 3)

class Sith(Personagem):
    def __init__(self, screen_width, screen_height):
        x = random.randint(40, screen_width - 40)
        y = random.randint(-300, -40)
        super().__init__("Sith", "vermelho", x, y, 60, 50, "sith.png")
        self.speed = random.randint(2, 4)
        self.direcao = random.choice([-1, 1])
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.passed = False

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > self.screen_height:
            self.rect.bottom = 0
            self.rect.x = random.randint(40, self.screen_width - 40)
            self.direcao = random.choice([-1, 1])
            self.passed = False

    def desenhar_barra_vida(self, superficie):
        largura = 40
        altura = 6
        percentagem = max(0, self.vida / self.vida_max)
        x = self.rect.centerx - largura // 2
        y = self.rect.top - 10

        if percentagem > 0.6:
            cor = (0, 255, 0)
        elif percentagem > 0.3:
            cor = (255, 255, 0)
        else:
            cor = (255, 0, 0)

        pygame.draw.rect(superficie, (100, 0, 0), (x, y, largura, altura))
        pygame.draw.rect(superficie, cor, (x, y, largura * percentagem, altura))

# ---------------- NAVE GIGANTE (BOSS) ----------------
class BossShip(pygame.sprite.Sprite):
    def __init__(self, screen_width, screen_height, boss_level=1):
        super().__init__()
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.boss_level = boss_level  # Nível do boss (aumenta a cada spawn)
        
        # Boss fica MAIS FORTE a cada nível! 🚀
        self.vida_max = 100 + (boss_level - 1) * 50  # +50 vida por nível
        self.vida = self.vida_max
        self.speed = 1 + (boss_level - 1) * 0.2  # +0.2 velocidade por nível
        self.shoot_cooldown = 2000 - (boss_level - 1) * 200  # -200ms por nível (mínimo 800ms)
        self.last_shot_time = 0
        self.damage = 1 + (boss_level - 1)  # +1 dano por nível
        
        self.image = pygame.Surface((150 + boss_level * 10, 80 + boss_level * 5), pygame.SRCALPHA)
        
        # Desenha nave gigante (fica maior com o nível)
        size_mult = 1 + (boss_level - 1) * 0.1
        pygame.draw.polygon(self.image, (80, 80, 100), [
            (75 * size_mult, 0), (150 * size_mult, 40), (130 * size_mult, 80), 
            (20 * size_mult, 80), (0, 40)
        ])
        pygame.draw.polygon(self.image, (120, 120, 150), [
            (75 * size_mult, 10), (130 * size_mult, 40), (110 * size_mult, 70), 
            (40 * size_mult, 70), (20 * size_mult, 40)
        ])
        
        # Luzes vermelhas (mais luzes com níveis superiores)
        num_lights = min(3 + boss_level, 6)
        for i in range(num_lights):
            x = 30 * size_mult + i * (25 * size_mult)
            pygame.draw.circle(self.image, (255, 0, 0), (int(x), 50), 8)
            pygame.draw.circle(self.image, (255, 100, 100), (int(x), 50), 4)
        
        self.rect = self.image.get_rect(center=(screen_width // 2, -50))
        self.direction = 1
        self.active = False
    
    def update(self):
        if self.active:
            self.rect.y += self.speed
            self.rect.x += self.direction * 2
            
            # Bater nas paredes
            if self.rect.left <= 0 or self.rect.right >= self.screen_width:
                self.direction *= -1
            
            # Quando chega à posição final
            if self.rect.top >= 50 and self.speed > 0:
                self.speed = 0
    
    def shoot(self, current_time, boss_bullets):
        """Boss dispara tiros! 🔫"""
        if current_time - self.last_shot_time >= self.shoot_cooldown:
            self.last_shot_time = current_time
            # Cria tiro do boss (vermelho, vai para baixo)
            bullet = BossBullet(self.rect.centerx, self.rect.bottom, self.damage)
            boss_bullets.add(bullet)
            som_boss_shoot.play()
            return True
        return False
    
    def desenhar_barra_vida(self, superficie):
        largura = 150
        altura = 10
        percentagem = max(0, self.vida / self.vida_max)
        x = self.rect.centerx - largura // 2
        y = self.rect.bottom + 10
        
        # Fundo da barra
        pygame.draw.rect(superficie, (100, 0, 0), (x, y, largura, altura))
        # Vida atual
        pygame.draw.rect(superficie, (255, 0, 0), (x, y, largura * percentagem, altura))
        # Borda
        pygame.draw.rect(superficie, (255, 255, 255), (x, y, largura, altura), 2)
        
        # Texto do nível do boss
        level_text = font.render(f"BOSS NÍVEL {self.boss_level}", True, (255, 255, 255))
        superficie.blit(level_text, (x, y - 25))

# ---------------- TIRO DO BOSS ----------------
class BossBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, damage=1):
        super().__init__()
        self.damage = damage
        self.image = pygame.Surface((15, 20), pygame.SRCALPHA)
        
        # Tiro vermelho do Boss 🔴
        pygame.draw.ellipse(self.image, (255, 0, 0), (0, 0, 15, 20))
        pygame.draw.ellipse(self.image, (255, 100, 100), (3, 2, 9, 16))
        pygame.draw.ellipse(self.image, (255, 200, 200), (5, 4, 5, 12))
        
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = 5  # Velocidade do tiro
    
    def update(self):
        self.rect.y += self.speed
        if self.rect.top > HEIGHT:
            self.kill()

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction=1):
        super().__init__()
        
        self.image = carregar_sprite("laser.png", 20, 8)
        
        if self.image.get_width() == 20 and self.image.get_height() == 8:
            self.image = pygame.Surface((20, 8), pygame.SRCALPHA)
            pygame.draw.ellipse(self.image, (0, 100, 255), (0, 0, 20, 8))
            pygame.draw.ellipse(self.image, (100, 200, 255), (2, 1, 16, 6))
            pygame.draw.ellipse(self.image, (200, 230, 255), (4, 2, 12, 4))
        
        self.rect = self.image.get_rect(center=(x, y))
        self.speed = -7
        self.direction = direction
    
    def update(self):
        self.rect.y += self.speed
        if self.rect.bottom < 0:
            self.kill()

class Explosao(pygame.sprite.Sprite):
    def __init__(self, x, y, grande=False):
        super().__init__()
        self.frames = []
        max_r = 80 if grande else 50
        for r in range(10, max_r, 8):
            img = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
            pygame.draw.circle(img, (255, 165, 0), (r, r), r)
            self.frames.append(img)
        self.index = 0
        self.image = self.frames[0]
        self.rect = self.image.get_rect(center=(x, y))

    def update(self):
        self.index += 0.3
        if self.index >= len(self.frames):
            self.kill()
        else:
            self.image = self.frames[int(self.index)]

# ---------------- RANKING ----------------
def carregar_ranking():
    try:
        with open(os.path.join(BASE_DIR, "ranking.json"), "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

def salvar_ranking(pontos, nome_jogador):
    ranking = carregar_ranking()
    ranking.append({"nome": nome_jogador[:10].upper(), "pontos": pontos})
    ranking.sort(key=lambda x: x["pontos"], reverse=True)
    ranking = ranking[:10]
    with open(os.path.join(BASE_DIR, "ranking.json"), "w") as f:
        json.dump(ranking, f, indent=2)

# ---------------- MENU ----------------
class MenuButton:
    def __init__(self, text, y_offset, callback):
        self.text = text
        self.y_offset = y_offset
        self.callback = callback
        self.width = 350
        self.height = 60
        self.rect = pygame.Rect(0, 0, self.width, self.height)
        self.rect.center = (WIDTH // 2, HEIGHT // 2 + y_offset)
        self.hover = False
        
    def draw(self, surface):
        if self.hover:
            cor_fundo = (80, 80, 150)
            cor_borda = (255, 255, 100)
            cor_texto = (255, 255, 100)
        else:
            cor_fundo = (40, 40, 80)
            cor_borda = (150, 150, 200)
            cor_texto = (200, 200, 255)
        
        pygame.draw.rect(surface, cor_fundo, self.rect, border_radius=15)
        pygame.draw.rect(surface, cor_borda, self.rect, 4, border_radius=15)
        
        texto = font.render(self.text, True, cor_texto)
        text_rect = texto.get_rect(center=self.rect.center)
        surface.blit(texto, text_rect)
    
    def check_hover(self, mouse_pos):
        self.hover = self.rect.collidepoint(mouse_pos)
        return self.hover
    
    def check_click(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)

class Menu:
    def __init__(self):
        self.buttons = [
            MenuButton("🎮 INICIAR JOGO", -80, lambda: STATE_PLAYING),
            MenuButton("🏆 RANKING", 0, lambda: STATE_RANKING),
            MenuButton("🚪 SAIR", 80, lambda: "quit")
        ]
        
    def draw(self, star_field, titulo="STAR WARS BATTLE"):
        star_field.draw(screen)
        
        draw_text_centered(titulo, font_large, (255, 215, 0), -200)
        subtitle = font.render("Setas para mover | ESPAÇO para atirar", True, (150, 200, 255))
        screen.blit(subtitle, (WIDTH // 2 - subtitle.get_width() // 2, HEIGHT // 2 - 170))
        
        mouse_pos = pygame.mouse.get_pos()
        for btn in self.buttons:
            btn.check_hover(mouse_pos)
            btn.draw(screen)
        
        pygame.display.flip()
    
    def handle_click(self, mouse_pos):
        for btn in self.buttons:
            if btn.check_click(mouse_pos):
                return btn.callback()
        return None

# ---------------- INPUT DE NOME ----------------
class TextInput:
    def __init__(self, max_length=10):
        self.texto = ""
        self.max_length = max_length
        self.cursor_visible = True
        self.cursor_timer = 0
        
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self.texto = self.texto[:-1]
            elif event.key == pygame.K_RETURN and len(self.texto.strip()) > 0:
                return self.texto.strip()
            elif len(self.texto) < self.max_length and event.unicode.isalnum():
                self.texto += event.unicode.upper()
        return None
    
    def update(self, dt):
        self.cursor_timer += dt
        if self.cursor_timer >= 0.5:
            self.cursor_visible = not self.cursor_visible
            self.cursor_timer = 0
    
    def draw(self, star_field, prompt="Digite seu nome:"):
        star_field.draw(screen)
        draw_text_centered("🏆 NOVO RECORD!", font_large, (255, 215, 0), -100)
        draw_text_centered(prompt, font, (200, 200, 255), -30)
        
        cursor = "|" if self.cursor_visible else " "
        texto_completo = f"{self.texto}{cursor}"
        input_render = font.render(texto_completo, True, (255, 255, 100))
        input_rect = input_render.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 20))
        
        pygame.draw.rect(screen, (50, 50, 100), input_rect.inflate(40, 20), border_radius=10)
        pygame.draw.rect(screen, (150, 150, 255), input_rect.inflate(40, 20), 3, border_radius=10)
        screen.blit(input_render, input_rect)
        
        draw_text_centered("Digite e pressione ENTER", font, (150, 150, 200), 80)
        pygame.display.flip()

# ---------------- GAME OVER ----------------
def draw_jedi_dead(surface, x, y):
    overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 150))
    surface.blit(overlay, (0, 0))
    
    pygame.draw.polygon(surface, (60, 60, 70), [(x-120,y-120),(x+120,y-120),(x+100,y-40),(x-100,y-40)])
    pygame.draw.polygon(surface, (80, 80, 90), [(x-80,y-110),(x+80,y-110),(x+60,y-50),(x-60,y-50)])
    for dx in [-70, 0, 70]:
        pygame.draw.circle(surface, (255, 0, 0), (x+dx, y-45), 8)
        pygame.draw.circle(surface, (255, 100, 100), (x+dx, y-45), 4)
    
    for i in range(12):
        o = i*3
        pygame.draw.line(surface, (180,0,0), (x-80+o, y-40), (x-50+o//2, y+30), 2)
        pygame.draw.line(surface, (200,0,0), (x+80-o, y-40), (x+50-o//2, y+30), 2)
    pygame.draw.line(surface, (255,50,50), (x, y-40), (x, y+30), 3)
    
    pygame.draw.ellipse(surface, (0,0,0,100), (x-40, y+55, 80, 15))
    pygame.draw.ellipse(surface, (101,67,33), (x-35, y+35, 70, 25))
    pygame.draw.ellipse(surface, (139,90,43), (x-30, y+38, 60, 18))
    pygame.draw.circle(surface, (255,220,180), (x-20, y+48), 14)
    pygame.draw.arc(surface, (62,39,35), (x-34, y+34, 28, 22), 0, 3.14, 4)
    pygame.draw.circle(surface, (255,220,180), (x-32, y+48), 4)
    for ex in [-26, -14]:
        pygame.draw.line(surface, (80,80,80), (x+ex, y+45), (x+ex+6, y+49), 2)
        pygame.draw.line(surface, (80,80,80), (x+ex+6, y+45), (x+ex, y+49), 2)
    pygame.draw.arc(surface, (100,50,50), (x-24, y+50, 16, 10), 0.2, 2.9, 2)
    pygame.draw.line(surface, (101,67,33), (x-35, y+45), (x-55, y+52), 5)
    pygame.draw.line(surface, (101,67,33), (x+20, y+45), (x+40, y+50), 5)
    pygame.draw.line(surface, (101,67,33), (x-15, y+55), (x-25, y+68), 6)
    pygame.draw.line(surface, (101,67,33), (x+5, y+55), (x+15, y+68), 6)
    
    pygame.draw.rect(surface, (120,120,120), (x+35, y+30, 10, 35))
    pygame.draw.rect(surface, (0,150,255), (x+36, y-28, 8, 62))
    pygame.draw.rect(surface, (150,220,255), (x+37, y-25, 6, 58))
    pygame.draw.circle(surface, (150,220,255), (x+40, y-10), 12)
    pygame.draw.circle(surface, (255,255,255), (x+40, y-30), 6)
    
    for _ in range(8):
        pygame.draw.circle(surface, (255,200,100), (x+random.randint(-60,60), y+random.randint(-20,40)), random.randint(2,4))
    
    txt = font_large.render("DERROTADO", True, (200,50,50))
    surface.blit(txt, txt.get_rect(center=(x, y-160)))

# ---------------- RANKING TABELA (SEM W, D, L) ----------------
def draw_league_table(surface, ranking):
    w, h = surface.get_width(), surface.get_height()
    surface.fill((10, 10, 30))
    
    title = font_large.render("LEAGUE TABLE", True, (255, 255, 255))
    surface.blit(title, (w // 2 - title.get_width() // 2, 30))
    
    header_bg = pygame.Rect(50, 80, w - 100, 40)
    pygame.draw.rect(surface, (0, 0, 0), header_bg)
    pygame.draw.rect(surface, (255, 255, 255), header_bg, 2)
    
    headers = ["POS", "CLUB", "POINTS"]
    header_x = [60, 200, 550]
    
    for i, header in enumerate(headers):
        text = font.render(header, True, (255, 255, 255))
        surface.blit(text, (header_x[i], 90))
    
    line_h = font.get_linesize()
    row_height = line_h + 14
    start_y = 130
    
    def get_row_color(pos):
        if pos <= 3: return (64, 224, 208)
        elif pos <= 6: return (255, 215, 0)
        else: return (255, 99, 71)
    
    def get_pos_color(pos):
        if pos == 1: return (255, 215, 0)
        elif pos == 2: return (192, 192, 192)
        elif pos == 3: return (205, 127, 50)
        else: return (255, 255, 255)
    
    for i, entry in enumerate(ranking[:10], 1):
        y = start_y + (i - 1) * row_height
        row_bg = pygame.Rect(50, y, w - 100, row_height - 2)
        color = get_row_color(i)
        pygame.draw.rect(surface, color, row_bg, border_radius=3)
        
        if i <= 3: border_color = (0, 255, 128)
        elif i <= 6: border_color = (255, 215, 0)
        else: border_color = (255, 100, 100)
        pygame.draw.rect(surface, border_color, (50, y, 5, row_height - 2))

        text_y = y + (row_height - line_h) // 2
        pos_color = get_pos_color(i)
        surface.blit(font.render(str(i), True, pos_color), (header_x[0], text_y))
        surface.blit(font.render(entry["nome"][:15], True, (255, 255, 255)), (header_x[1], text_y))
        surface.blit(font.render(str(entry["pontos"]), True, (255, 215, 0)), (header_x[2], text_y))
    
    instructions = font.render("Clica ou ESC para voltar", True, (150, 200, 255))
    surface.blit(instructions, (w // 2 - instructions.get_width() // 2, h - 50))
    pygame.display.flip()

# ---------------- JOGO PRINCIPAL ----------------
def init_game():
    all_sprites = pygame.sprite.Group()
    bullets = pygame.sprite.Group()
    enemies = pygame.sprite.Group()
    boss_bullets = pygame.sprite.Group()  # Tiros do Boss
    
    jedi = Jedi()
    all_sprites.add(jedi)
    
    # 3 Siths normais
    for _ in range(3):
        sith = Sith(WIDTH, HEIGHT)
        enemies.add(sith)
        all_sprites.add(sith)
    
    return all_sprites, bullets, enemies, jedi, boss_bullets

def game_loop():
    state = STATE_MENU
    player_name = "JOGADOR"
    pontuacao = 0
    
    star_field = StarField()
    all_sprites = bullets = enemies = jedi = boss = boss_bullets = None
    menu = Menu()
    name_input = TextInput()
    
    last_shot_time = 0
    SHOT_COOLDOWN = 200
    MAX_BULLETS_ON_SCREEN = 3
    
    # Variáveis do Boss
    boss_active = False
    boss_spawned_at = 0
    boss_level = 1  # Nível do boss aumenta progressivamente
    siths_backup = []  # Guarda Siths quando boss aparece
    
    running = True
    while running:
        clock.tick(60)
        star_field.update()
        pygame.mouse.set_visible(True)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                click_pos = event.pos
                
                if state == STATE_MENU:
                    result = menu.handle_click(click_pos)
                    if result == STATE_PLAYING:
                        all_sprites, bullets, enemies, jedi, boss_bullets = init_game()
                        pontuacao = 0
                        boss = None
                        boss_active = False
                        boss_level = 1
                        state = STATE_PLAYING
                    elif result == STATE_RANKING:
                        state = STATE_RANKING
                    elif result == "quit":
                        running = False
                        
                elif state == STATE_RANKING:
                    state = STATE_MENU
                    
                elif state == STATE_GAME_OVER:
                    state = STATE_MENU
            
            if state == STATE_NAME_INPUT:
                nome = name_input.handle_event(event)
                if nome:
                    player_name = nome
                    salvar_ranking(pontuacao, player_name)
                    state = STATE_GAME_OVER
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if state in [STATE_RANKING, STATE_GAME_OVER, STATE_PLAYING]:
                        state = STATE_MENU
                
                if event.key == pygame.K_SPACE and state == STATE_PLAYING:
                    current_time = pygame.time.get_ticks()
                    
                    # LIMITE DE TIROS DESAPARECE DURANTE O BOSS!
                    if boss_active:
                        if current_time - last_shot_time >= SHOT_COOLDOWN:
                            saber_x, saber_y = jedi.get_saber_position()
                            tiro = Bullet(saber_x, saber_y, jedi.direcao)
                            bullets.add(tiro)
                            all_sprites.add(tiro)
                            som_laser.play()
                            last_shot_time = current_time
                    else:
                        if (current_time - last_shot_time >= SHOT_COOLDOWN and 
                            len(bullets) < MAX_BULLETS_ON_SCREEN):
                            saber_x, saber_y = jedi.get_saber_position()
                            tiro = Bullet(saber_x, saber_y, jedi.direcao)
                            bullets.add(tiro)
                            all_sprites.add(tiro)
                            som_laser.play()
                            last_shot_time = current_time
        
        if state == STATE_NAME_INPUT:
            name_input.update(1/60)
            
        if state == STATE_PLAYING:
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] and jedi.rect.left > 0:
                jedi.rect.x -= jedi.speed
                jedi.direcao = -1
            if keys[pygame.K_RIGHT] and jedi.rect.right < WIDTH:
                jedi.rect.x += jedi.speed
                jedi.direcao = 1
            
            # SPAWN DO BOSS A CADA 100 PONTOS
            if pontuacao > 0 and pontuacao % 100 == 0 and not boss_active and pontuacao != boss_spawned_at:
                boss_active = True
                boss_spawned_at = pontuacao
                
                # GUARDA SITHS E REMOVE-OS QUANDO BOSS APARECE! 🚀
                siths_backup = list(enemies)
                for sith in siths_backup:
                    sith.kill()
                enemies.empty()
                
                # Cria Boss com nível progressivo
                boss = BossShip(WIDTH, HEIGHT, boss_level)
                boss.active = True
                all_sprites.add(boss)
                som_boss.play()
            
            all_sprites.update()
            if boss_bullets:
                boss_bullets.update()
            
            # Boss dispara tiros! 🔫
            if boss_active and boss:
                boss.shoot(pygame.time.get_ticks(), boss_bullets)
            
            # Verificar se Sith passou pelo Jedi (PERDE 10 PONTOS) - só quando não há boss
            if not boss_active:
                for enemy in enemies:
                    if enemy.rect.top > HEIGHT and not enemy.passed:
                        enemy.passed = True
                        pontuacao = max(0, pontuacao - 10)
            
            # Colisão tiro ↔ Sith (só quando não há boss)
            if not boss_active:
                hits = pygame.sprite.groupcollide(enemies, bullets, False, True)
                for enemy in hits:
                    enemy.sofrer_dano(25)
                    if enemy.vida <= 0:
                        pontuacao += 10
                        som_explosao.play()
                        all_sprites.add(Explosao(enemy.rect.centerx, enemy.rect.centery))
                        enemy.kill()
                        novo = Sith(WIDTH, HEIGHT)
                        enemies.add(novo)
                        all_sprites.add(novo)
            
            # Colisão tiro ↔ Boss
            if boss_active and boss:
                boss_hits = pygame.sprite.groupcollide([boss], bullets, False, True)
                for b in boss_hits:
                    b.vida -= 25
                    if b.vida <= 0:
                        pontuacao += 50
                        som_explosao.play()
                        all_sprites.add(Explosao(b.rect.centerx, b.rect.centery, grande=True))
                        b.kill()
                        boss = None
                        boss_active = False
                        boss_level += 1  # Próximo boss mais forte!
                        
                        # RESTAURA SITHS QUANDO BOSS MORRE! 👾
                        for sith in siths_backup:
                            enemies.add(sith)
                            all_sprites.add(sith)
                        siths_backup = []
            
            # Colisão tiro do Boss ↔ Jedi 💀
            if boss_active:
                boss_bullet_hits = pygame.sprite.spritecollide(jedi, boss_bullets, True)
                for bb in boss_bullet_hits:
                    jedi.vidas -= bb.damage
                    if jedi.vidas <= 0:
                        ranking = carregar_ranking()
                        if len(ranking) < 10 or pontuacao > min(r["pontos"] for r in ranking):
                            name_input.texto = player_name
                            state = STATE_NAME_INPUT
                        else:
                            salvar_ranking(pontuacao, player_name)
                            state = STATE_GAME_OVER
            
            # Colisão Jedi ↔ Sith (só quando não há boss)
            if not boss_active:
                colisoes = pygame.sprite.spritecollide(jedi, enemies, True)
                if colisoes:
                    jedi.vidas -= 1
                    jedi.rect.center = (WIDTH // 2, HEIGHT - 60)
                    novo = Sith(WIDTH, HEIGHT)
                    enemies.add(novo)
                    all_sprites.add(novo)
                    
                    if jedi.vidas <= 0:
                        ranking = carregar_ranking()
                        if len(ranking) < 10 or pontuacao > min(r["pontos"] for r in ranking):
                            name_input.texto = player_name
                            state = STATE_NAME_INPUT
                        else:
                            salvar_ranking(pontuacao, player_name)
                            state = STATE_GAME_OVER
            
            # Colisão Jedi ↔ Boss
            if boss_active and boss and pygame.sprite.collide_rect(jedi, boss):
                jedi.vidas -= 1
                jedi.rect.center = (WIDTH // 2, HEIGHT - 60)
                if jedi.vidas <= 0:
                    ranking = carregar_ranking()
                    if len(ranking) < 10 or pontuacao > min(r["pontos"] for r in ranking):
                        name_input.texto = player_name
                        state = STATE_NAME_INPUT
                    else:
                        salvar_ranking(pontuacao, player_name)
                        state = STATE_GAME_OVER
        
        if state == STATE_MENU:
            menu.draw(star_field)
            
        elif state == STATE_RANKING:
            ranking = carregar_ranking()
            draw_league_table(screen, ranking)
            
        elif state == STATE_NAME_INPUT:
            name_input.draw(star_field)
            
        elif state == STATE_PLAYING:
            star_field.draw(screen)
            
            jedi.draw(screen)
            
            for sprite in all_sprites:
                if sprite != jedi:
                    screen.blit(sprite.image, sprite.rect)
            
            # Desenha tiros do Boss
            if boss_bullets:
                boss_bullets.draw(screen)
            
            for enemy in enemies:
                enemy.desenhar_barra_vida(screen)
            
            # Barra de vida do Boss
            if boss_active and boss:
                boss.desenhar_barra_vida(screen)
            
            texto_score = font.render(f"Score: {pontuacao}", True, (255, 255, 100))
            screen.blit(texto_score, (10, 10))
            texto_vidas = font.render(f"Vidas: {jedi.vidas}", True, (100, 255, 100))
            screen.blit(texto_vidas, (WIDTH - 120, 10))
            
            # Mostrar status do limite de tiros
            if boss_active:
                texto_limite = font.render("🚀 BOSS NÍVEL " + str(boss_level) + " - TIROS ILIMITADOS!", True, (255, 100, 100))
            else:
                texto_limite = font.render(f"Tiros: {len(bullets)}/{MAX_BULLETS_ON_SCREEN}", True, (150, 200, 255))
            screen.blit(texto_limite, (WIDTH//2 - texto_limite.get_width()//2, 10))
            
            current_time = pygame.time.get_ticks()
            if current_time - last_shot_time < SHOT_COOLDOWN and not boss_active:
                cooldown_pct = (current_time - last_shot_time) / SHOT_COOLDOWN
                pygame.draw.rect(screen, (100, 100, 100), (WIDTH//2 - 30, 35, 60, 5))
                pygame.draw.rect(screen, (100, 255, 100), (WIDTH//2 - 30, 35, 60 * (1-cooldown_pct), 5))
            
            controles = font.render("Setas: Mover | ESPAÇO: Atirar da Espada ⚔️", True, (150, 200, 255))
            screen.blit(controles, (WIDTH//2 - controles.get_width()//2, HEIGHT - 30))
            
            pygame.display.flip()
            
        elif state == STATE_GAME_OVER:
            star_field.draw(screen)
            draw_jedi_dead(screen, WIDTH // 2, HEIGHT // 2 - 30)
            draw_text_centered(f"Pontuação Final: {pontuacao}", font, (255, 255, 100), 140)
            
            ranking = carregar_ranking()
            if ranking:
                draw_text_centered("TOP 3 RANKING", font, (255, 215, 0), 190)
                line_h = font.get_linesize()
                for i, registo in enumerate(ranking[:3], 1):
                    cor = (255, 215, 0) if i == 1 else (192, 192, 192) if i == 2 else (205, 127, 50)
                    linha = f"{i}º {registo['nome']}: {registo['pontos']} pts"
                    draw_text_centered(linha, font, cor, 220 + i * (line_h + 8))
            
            draw_text_centered("Clica ou ENTER: Menu | ESC: Sair", font, (100, 200, 100), 280)
            pygame.display.flip()

    return player_name

# ---------------- MAIN ----------------
if __name__ == "__main__":
    print("🚀 Star Wars Battle - A iniciar...")
    print(f"📁 Pasta do jogo: {BASE_DIR}")
    print(f"🔊 som_laser: {type(som_laser).__name__} (laser.wav)")
    print(f"⚔️  laser.png: {os.path.exists(os.path.join(BASE_DIR, 'laser.png'))}")
    print("=" * 50)
    
    while True:
        resultado = game_loop()
        try:
            with open(os.path.join(BASE_DIR, "config.json"), "w") as f:
                json.dump({"last_player": resultado}, f)
        except:
            pass
        break

    pygame.quit()