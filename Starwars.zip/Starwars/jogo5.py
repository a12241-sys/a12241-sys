# ============================================================
# 🚀 STAR WARS BATTLE
# Jogo desenvolvido em Pygame
# O jogador controla um Jedi que combate Siths e Bosses
# Inclui sistema de ranking, boss progressivo e efeitos sonoros
# ============================================================

# ---------------- IMPORTAÇÕES ----------------
# pygame → Biblioteca principal para criar o jogo
# random → Para gerar posições e valores aleatórios
# os → Trabalhar com caminhos de ficheiros
# json → Guardar e ler o ranking
# math → Usado para gerar sons artificiais
# array → Criar buffers de som manualmente
import pygame
import random
import os
import json
import math
import array

# Inicializa todos os módulos do pygame
pygame.init()

# Inicializa o sistema de som
pygame.mixer.init()

# ---------------- CONFIGURAÇÃO DA JANELA ----------------

# Define largura e altura da janela
WIDTH, HEIGHT = 800, 600

# Cria a janela principal do jogo
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Define o título da janela
pygame.display.set_caption("Star Wars Battle")

# Controla os FPS (frames por segundo)
clock = pygame.time.Clock()

# Fontes usadas no jogo
font = pygame.font.SysFont(None, 30)
font_large = pygame.font.SysFont(None, 50)

# Pasta base onde está o ficheiro
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------------- ESTADOS DO JOGO ----------------
# Controlam o fluxo do jogo

STATE_MENU = "menu"            # Menu principal
STATE_PLAYING = "playing"      # Durante o jogo
STATE_GAME_OVER = "game_over"  # Tela de derrota
STATE_NAME_INPUT = "name_input"  # Inserir nome no ranking
STATE_RANKING = "ranking"      # Tela de ranking

# ---------------- CARREGAMENTO DE SONS ----------------
# Função para carregar sons do jogo
# Se o ficheiro não existir, gera um som simples automaticamente
def _load_sound(nome_arquivo):
    caminho = os.path.join(BASE_DIR, nome_arquivo)
    try:
        # Verifica se o ficheiro existe
        if os.path.exists(caminho):
            return pygame.mixer.Sound(caminho)
        else:
            print(f"⚠️  Aviso: Ficheiro '{nome_arquivo}' não encontrado")
    except Exception as e:
        print(f"⚠️  Erro ao carregar '{nome_arquivo}': {e}")
    
    # Caso o ficheiro não exista, cria um som alternativo
    print(f"🔊 A gerar som de fallback para '{nome_arquivo}'")
    
    frequency = 800 if "laser" in nome_arquivo else 150
    duration = 0.15 if "laser" in nome_arquivo else 0.3
    volume = 0.3
    
    samples = []
    for i in range(int(44100 * duration)):
        if "laser" in nome_arquivo:
            freq = frequency * (1 - i / (44100 * duration) * 0.5)
        else:
            freq = frequency
        value = int(volume * 32767 * math.sin(2 * math.pi * freq * i / 44100))
        samples.append(value)
        samples.append(value)
    
    buffer = array.array('h', samples)
    sound = pygame.mixer.Sound(buffer=buffer)
    sound.set_volume(0.5)
    return sound

# Carrega todos os sons usados no jogo
som_laser = _load_sound("laser.wav")
som_explosao = _load_sound("explosion.wav")
som_boss = _load_sound("boss.wav")
som_boss_shoot = _load_sound("boss_shoot.wav")

# Define número de canais de som
pygame.mixer.set_num_channels(16)

# Define volume dos sons
som_laser.set_volume(0.5)
som_explosao.set_volume(0.5)
som_boss.set_volume(0.5)
som_boss_shoot.set_volume(0.5)

# ---------------- FUNÇÕES AUXILIARES ----------------

# Função para carregar imagens (sprites)
# Se não encontrar a imagem, cria um retângulo verde temporário
def carregar_sprite(nome, largura, altura):
    try:
        img = pygame.image.load(os.path.join(BASE_DIR, nome)).convert_alpha()
        return pygame.transform.scale(img, (largura, altura))
    except Exception:
        surf = pygame.Surface((largura, altura), pygame.SRCALPHA)
        pygame.draw.rect(surf, (0, 255, 0), (0, 0, largura, altura))
        return surf

# Função para desenhar texto centrado no ecrã
def draw_text_centered(text, font, color, y_offset=0, surface=None):
    if surface is None:
        surface = screen
    texto = font.render(text, True, color)
    rect = texto.get_rect(center=(surface.get_width() // 2, surface.get_height() // 2 + y_offset))
    surface.blit(texto, rect)

# ---------------- FUNDO ESPACIAL ----------------
# Classe que cria o efeito de estrelas em movimento
class StarField:
    def __init__(self):
        self.stars = []
        # Cria 150 estrelas com posição e velocidade aleatória
        for _ in range(150):
            x = random.randint(0, WIDTH)
            y = random.randint(0, HEIGHT)
            size = random.randint(1, 3)
            speed = random.randint(1, 4)
            brightness = random.randint(150, 255)
            self.stars.append([x, y, size, speed, brightness])
    
    # Atualiza posição das estrelas
    def update(self):
        for star in self.stars:
            star[1] += star[3]
            if star[1] > HEIGHT:
                star[1] = 0
                star[0] = random.randint(0, WIDTH)
    
    # Desenha o fundo e as estrelas
    def draw(self, surface):
        surface.fill((0, 0, 20))
        for star in self.stars:
            pygame.draw.circle(surface, (star[4], star[4], star[4]), (int(star[0]), int(star[1])), star[2])